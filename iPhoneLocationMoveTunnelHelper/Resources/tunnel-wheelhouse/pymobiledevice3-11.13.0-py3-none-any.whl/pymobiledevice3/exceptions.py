__all__ = [
    "AccessDeniedError",
    "AfcException",
    "AfcFileNotFoundError",
    "AlreadyMountedError",
    "AmfiError",
    "ArbitrationError",
    "ArgumentError",
    "BackupFilterPasswordRequiredError",
    "BadCommandError",
    "BadDevError",
    "CannotStopSessionError",
    "CloudConfigurationAlreadyPresentError",
    "ConnectionFailedError",
    "ConnectionFailedToUsbmuxdError",
    "ConnectionTerminatedError",
    "CoreDeviceError",
    "DeprecationError",
    "DeveloperModeError",
    "DeveloperModeIsNotEnabledError",
    "DeviceAlreadyInUseError",
    "DeviceFeatureNotSupportedError",
    "DeviceHasPasscodeSetError",
    "DeviceNotFoundError",
    "DeviceVersionNotSupportedError",
    "DisableMemoryLimitError",
    "DvtDirListError",
    "DvtException",
    "ExtractingStackshotError",
    "FatalPairingError",
    "FeatureNotSupportedError",
    "GetProhibitedError",
    "IRecvError",
    "IRecvNoDeviceConnectedError",
    "IncorrectModeError",
    "InspectorEvaluateError",
    "InternalError",
    "InvalidConnectionError",
    "InvalidHostIDError",
    "InvalidServiceError",
    "LaunchingApplicationError",
    "LockdownError",
    "MCProtectedError",
    "MessageNotSupportedError",
    "MissingValueError",
    "MuxException",
    "MuxVersionError",
    "NoDeviceConnectedError",
    "NotConnectedError",
    "NotEnoughDiskSpaceError",
    "NotMountedError",
    "NotPairedError",
    "NotTrustedError",
    "NotificationTimeoutError",
    "OSNotSupportedError",
    "PairingDialogResponsePendingError",
    "PairingError",
    "PasscodeRequiredError",
    "PasswordRequiredError",
    "ProfileError",
    "PskCipherNotSupportedError",
    "PyMobileDevice3Exception",
    "QuicProtocolNotSupportedError",
    "RSDRequiredError",
    "RemoteAutomationNotEnabledError",
    "RemotePairingCompletedError",
    "ScreencastUnavailableError",
    "SessionActiveError",
    "SetProhibitedError",
    "StartServiceError",
    "SysdiagnoseTimeoutError",
    "TSSError",
    "TunneldConnectionError",
    "UnrecognizedSelectorError",
    "UnsupportedCommandError",
    "UserDeniedPairingError",
    "UserspaceTunnelUnavailableError",
    "WdaError",
    "WebInspectorNotEnabledError",
    "WirError",
]

from typing import Optional


class PyMobileDevice3Exception(Exception):
    pass


class DeviceVersionNotSupportedError(PyMobileDevice3Exception):
    pass


class IncorrectModeError(PyMobileDevice3Exception):
    pass


class NotTrustedError(PyMobileDevice3Exception):
    pass


class PairingError(PyMobileDevice3Exception):
    pass


class NotPairedError(PyMobileDevice3Exception):
    pass


class CannotStopSessionError(PyMobileDevice3Exception):
    pass


class PasswordRequiredError(PairingError):
    pass


class BackupFilterPasswordRequiredError(PyMobileDevice3Exception):
    pass


class StartServiceError(PyMobileDevice3Exception):
    def __init__(self, service_name: str, message: str) -> None:
        super().__init__()
        self.service_name = service_name
        self.message = message


class FatalPairingError(PyMobileDevice3Exception):
    pass


class NoDeviceConnectedError(PyMobileDevice3Exception):
    pass


class NotConnectedError(PyMobileDevice3Exception):
    """Raised when a service is used before its connect() (or async-context enter) has run."""

    pass


class InterfaceIndexNotFoundError(PyMobileDevice3Exception):
    def __init__(self, address: str):
        super().__init__()
        self.address = address


class DeviceNotFoundError(PyMobileDevice3Exception):
    """A device with the requested UDID was not found by the transport that was asked for it.

    Every raise site passes a message naming the lookup that failed (usbmux, tunneld,
    remotepairingd, ...) — ``str(exc)`` is therefore self-explanatory — while ``udid`` remains a
    dedicated member so callers can act on the target itself.
    """

    def __init__(self, udid: Optional[str], message: Optional[str] = None) -> None:
        super().__init__(message or f"Device not found: {udid}")
        self.udid = udid


class TunneldConnectionError(PyMobileDevice3Exception):
    pass


class MuxException(PyMobileDevice3Exception):
    pass


class MuxVersionError(MuxException):
    pass


class BadCommandError(MuxException):
    pass


class BadDevError(MuxException):
    pass


class ConnectionFailedError(MuxException):
    pass


class ConnectionFailedToUsbmuxdError(ConnectionFailedError):
    pass


class ArgumentError(PyMobileDevice3Exception):
    pass


class AfcException(PyMobileDevice3Exception, OSError):
    def __init__(self, message: str, status: Optional[int], filename: Optional[str] = None) -> None:
        # status carries the AfcError code (an IntEnum in services/afc.py, not importable here without a cycle)
        OSError.__init__(self, status, message)
        self.status = status
        self.filename = filename


class AfcFileNotFoundError(AfcException):
    pass


class DvtException(PyMobileDevice3Exception):
    """Domain exception for DVT operations."""

    pass


class UnrecognizedSelectorError(DvtException):
    """Attempted to call an unrecognized selector from DVT."""

    pass


class DvtDirListError(DvtException):
    """Raise when directory listing fails."""

    pass


class NotMountedError(PyMobileDevice3Exception):
    """Given image for umount wasn't mounted in the first place"""

    pass


class AlreadyMountedError(PyMobileDevice3Exception):
    """Given image for mount has already been mounted in the first place"""

    pass


class MissingManifestError(PyMobileDevice3Exception):
    """No manifest could be found"""

    pass


class UnsupportedCommandError(PyMobileDevice3Exception):
    """Given command isn't supported for this iOS version"""

    pass


class ExtractingStackshotError(PyMobileDevice3Exception):
    """Raise when stackshot is not received in the core profile session."""

    pass


class ChannelClosedError(PyMobileDevice3Exception):
    """Raised when trying to send or read a message on a closed channel."""

    pass


class ConnectionTerminatedError(PyMobileDevice3Exception):
    """Raise when a connection is terminated abruptly."""

    pass


class StreamClosedError(ConnectionTerminatedError):
    """Raise when trying to send a message on a closed stream."""

    pass


class WebInspectorNotEnabledError(PyMobileDevice3Exception):
    """Raise when Web Inspector is not enabled."""

    pass


class ScreencastUnavailableError(PyMobileDevice3Exception):
    """Raise when a debuggable cannot be screencast (it has no page to capture)."""

    pass


class RemoteAutomationNotEnabledError(PyMobileDevice3Exception):
    """Raise when Web Inspector remote automation is not enabled."""

    pass


class WirError(PyMobileDevice3Exception):
    """Raise when Webinspector WIR command fails."""

    pass


class InternalError(PyMobileDevice3Exception):
    """Some internal Apple error"""

    pass


class ArbitrationError(PyMobileDevice3Exception):
    """Arbitration failed"""

    pass


class DeviceAlreadyInUseError(ArbitrationError):
    """Device is already checked-in by someone"""

    @property
    def message(self):
        return self.args[0].get("message")

    @property
    def owner(self):
        return self.args[0].get("owner")

    @property
    def result(self):
        return self.args[0].get("result")


class DeveloperModeIsNotEnabledError(PyMobileDevice3Exception):
    """Raise when mounting failed because developer mode is not enabled."""

    pass


class DeveloperDiskImageNotFoundError(PyMobileDevice3Exception):
    """Failed to locate the correct DeveloperDiskImage.dmg"""

    pass


class DeveloperModeError(PyMobileDevice3Exception):
    """Raise when amfid failed to enable developer mode."""

    pass


class LockdownError(PyMobileDevice3Exception):
    """lockdown general error"""

    def __init__(self, message: str, identifier: Optional[str], product_version: str) -> None:
        super().__init__(message)
        # identifier is Optional only to match the base LockdownClient contract (its constructor
        # permits an unknown identifier); every factory-built client (usbmux/TCP/RemoteXPC)
        # populates it. product_version is always set (the lockdown/RSD property never returns None).
        self.identifier = identifier
        self.product_version = product_version


class GetProhibitedError(LockdownError):
    pass


class SetProhibitedError(LockdownError):
    pass


class PairingDialogResponsePendingError(PairingError):
    """User hasn't yet confirmed the device is trusted"""

    pass


class UserDeniedPairingError(PairingError):
    pass


class InvalidHostIDError(PairingError):
    pass


class MissingValueError(LockdownError):
    """raised when attempting to query non-existent domain/key"""

    pass


class InvalidConnectionError(LockdownError):
    pass


class PasscodeRequiredError(LockdownError):
    """passcode must be present for this action"""

    pass


class MCProtectedError(LockdownError):
    """mobile configuration policy prohibits this action"""

    pass


class SessionActiveError(LockdownError):
    """a lockdown session is already active"""

    pass


class AmfiError(PyMobileDevice3Exception):
    pass


class DeviceHasPasscodeSetError(AmfiError):
    pass


class NotificationTimeoutError(PyMobileDevice3Exception, TimeoutError):
    pass


class ProfileError(PyMobileDevice3Exception):
    pass


class CloudConfigurationAlreadyPresentError(ProfileError):
    pass


class IRecvError(PyMobileDevice3Exception):
    pass


class IRecvNoDeviceConnectedError(IRecvError):
    pass


class MessageNotSupportedError(PyMobileDevice3Exception):
    pass


class InvalidServiceError(LockdownError):
    pass


class DeviceFeatureNotSupportedError(LockdownError):
    """The device's RSD handshake does not advertise a feature required for the operation."""

    def __init__(self, service_name: str, feature: str, identifier: Optional[str], product_version: str) -> None:
        super().__init__(
            f"device does not support feature {feature!r} (service {service_name!r})", identifier, product_version
        )
        self.service_name = service_name
        self.feature = feature


class InspectorEvaluateError(PyMobileDevice3Exception):
    def __init__(
        self,
        class_name: str,
        message: str,
        line: Optional[int] = None,
        column: Optional[int] = None,
        stack: Optional[list[str]] = None,
    ):
        super().__init__()
        self.class_name = class_name
        self.message = message
        self.line = line
        self.column = column
        self.stack = stack

    def __str__(self) -> str:
        stack_trace = "\n".join([f"\t - {frame}" for frame in self.stack or []])
        return f"{self.class_name}: {self.message}.\nLine: {self.line} Column: {self.column}\nStack: {stack_trace}"


class LaunchingApplicationError(PyMobileDevice3Exception):
    pass


class AppInstallError(PyMobileDevice3Exception):
    pass


class AppNotInstalledError(PyMobileDevice3Exception):
    pass


class CoreDeviceError(PyMobileDevice3Exception):
    pass


class CryptexdError(PyMobileDevice3Exception):
    """cryptexd rejected a routine, reporting a CFError or a non-zero error code"""

    pass


class InstallCoordinationError(PyMobileDevice3Exception):
    """installcoordination_proxy reported a failed request"""

    pass


class AccessDeniedError(PyMobileDevice3Exception):
    """Need extra permissions to execute this command"""

    pass


class NoSuchBuildIdentityError(PyMobileDevice3Exception):
    pass


class MobileActivationException(PyMobileDevice3Exception):
    """Mobile activation can not be done"""

    pass


class NotEnoughDiskSpaceError(PyMobileDevice3Exception):
    """Computer does not have enough disk space for the intended operation"""

    pass


class DeprecationError(PyMobileDevice3Exception):
    """The requested action/service/method is deprecated"""

    pass


class RSDRequiredError(PyMobileDevice3Exception):
    """The requested action requires an RSD object"""

    def __init__(self, identifier: Optional[str], product_version: str) -> None:
        self.identifier = identifier
        self.product_version = product_version
        super().__init__()


class RoutableTunnelRequiredError(PyMobileDevice3Exception):
    """The action exposes the device's tunnel address to an external process (e.g. lldb), which
    needs a kernel-routable tunnel. The active tunnel is an in-process userspace tunnel whose
    address is only reachable from this process."""


class UserspaceTunnelUnavailableError(PyMobileDevice3Exception):
    """The no-root in-process userspace tunnel cannot serve this device — e.g. iOS 17.0-17.3 (no
    CoreDeviceProxy service) with the RemotePairing fallback disabled or no RemotePairing service
    reachable. Callers that require an RSD (e.g. the CLI) can catch this and route to a privileged
    kernel tunnel (``tunneld``) instead."""


class SysdiagnoseTimeoutError(PyMobileDevice3Exception, TimeoutError):
    """Timeout collecting new sysdiagnose archive"""

    pass


class SupportError(PyMobileDevice3Exception):
    def __init__(self, os_name: Optional[str]) -> None:
        self.os_name = os_name
        super().__init__()


class OSNotSupportedError(SupportError):
    """Operating system is not supported."""

    pass


class FeatureNotSupportedError(SupportError):
    """Feature has not been implemented for OS."""

    def __init__(self, os_name: Optional[str], feature: str) -> None:
        super().__init__(os_name)
        self.feature = feature


class QuicProtocolNotSupportedError(PyMobileDevice3Exception):
    """QUIC tunnel support was removed on iOS 18.2+"""


class PskCipherNotSupportedError(PyMobileDevice3Exception):
    """The active Python's SSL backend cannot select the PSK ciphers required for the TCP tunnel"""

    pass


class RemotePairingCompletedError(PyMobileDevice3Exception):
    """
    Raised upon pairing completion using the `remotepairingdeviced` service (RemoteXPC).

    remotepairingdeviced closes connection after pairing, so client must re-establish it after pairing is
    completed.
    """

    pass


class DisableMemoryLimitError(PyMobileDevice3Exception):
    """Disabling memory limit fails."""

    pass


class ProtocolError(PyMobileDevice3Exception):
    """An unexpected protocol message was received"""

    pass


class TSSError(PyMobileDevice3Exception):
    """An unexpected message was received from apple ticket server"""

    pass


class WdaError(PyMobileDevice3Exception):
    """Raised for WebDriverAgent (WDA) errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code
