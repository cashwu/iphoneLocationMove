import dataclasses
import math
import os
import struct
from collections.abc import AsyncGenerator, Callable, Generator
from io import BytesIO
from typing import Any, cast

from pymobiledevice3.dtx_service_provider import DtxServiceProvider
from pymobiledevice3.services.dvt.instruments.tap import Tap

CMD_DEFINE_TABLE = 1
CMD_END_ROW = 2
CMD_CONVERT_MACH_CONTINUOUS = 5
CMD_TABLE_RESET = 0x64
CMD_COPY = 0x65
CMD_SENTINEL = 0x68
CMD_STRUCT = 0x69
CMD_PLACEHOLDER_COUNT = 0x6A
CMD_DEBUG = 0x6B


@dataclasses.dataclass
class Table:
    unknown0: str
    unknown2: str
    name: str
    columns: list[Any]


def decode_str(s: bytes):
    return s.split(b"\x00", 1)[0].decode()


def ignored_null(s: bytes) -> bytes:
    if len(s) == 0:
        return s

    if s[-1] == 0:
        s = s[:-1]
    return s


def decode_message_format(message: Any) -> str:
    s = ""
    for type_, data in message:
        if data and isinstance(data, bytes):
            data = ignored_null(data)
        type_ = decode_str(type_)

        if type_ == "address":
            type_ = "uint64-hex"

        if type_ in ("narrative-text", "string"):
            if data is None:
                s += "<None>"
            else:
                s += data.decode()
        elif type_ == "private":
            s += "<private>"
        elif type_.startswith("uint64"):
            uint64 = struct.unpack("<Q", data.ljust(8, b"\x00"))[0]
            if "hex" in type_:
                uint64 = hex(uint64)[2:]
                if "lowercase" in type_:
                    uint64 = uint64.lower()
            s += str(uint64)
        elif "decimal" in type_:
            uint64 = struct.unpack("<Q", data.ljust(8, b"\x00"))[0]
            s += str(uint64)
        elif type_ in ("data", "uuid"):
            if data is not None:
                # for these types the payload is a list of bytes chunks, not a single bytes object
                s += b"".join(cast(list[bytes], data)).hex()
        else:
            # by default, make sure the data can be concatenated
            s += str(data)
    return s


class ActivityTraceTap(Tap):
    """
    Tap the device's unified-logging / activity-trace stream over the Instruments channel.

    Constructed with a `DvtProvider`. It is an async-iterable `Tap`: iterating yields decoded
    log entries (signposts and os_log messages) as `message` dataclass instances whose fields
    follow the table columns advertised by the device. The underlying wire format is a
    stack-based opcode stream parsed incrementally; opcodes split across DTX frames are carried
    over and reassembled.
    """

    IDENTIFIER = "com.apple.instruments.server.services.activitytracetap"

    def __init__(self, dvt: DtxServiceProvider, enable_http_archive_logging: bool = False):
        """
        :param dvt: The `DvtProvider` used to open the Instruments channel.
        :param enable_http_archive_logging: When True, request that the device also include HTTP
            archive (HAR) logging in the stream.
        """
        # TODO:
        #   reverse: [DTOSLogLoader _handleRecord:], DTTableRowEncoder::*
        #   to understand each row's structure.

        config: dict[str, Any] = {
            "bm": 0,  # buffer mode
            "combineDataScope": 0,
            "machTimebaseDenom": 3,
            "machTimebaseNumer": 125,
            "onlySignposts": 0,
            "pidToInjectCombineDYLIB": "-1",
            "predicate": "(messageType == info OR messageType == debug OR messageType == default OR "
            "messageType == error OR messageType == fault)",
            "signpostsAndLogs": 1,
            "trackPidToExecNameMapping": True,
            "enableHTTPArchiveLogging": enable_http_archive_logging,
            "targetPID": -3,  # all Process
            "trackExpiredPIDs": 1,
            "ur": 500,
        }

        super().__init__(dvt, self.IDENTIFIER, config)

        self.stack: list[Any] = []
        self.generation = 0
        self.background = 0
        self.tables: list[Table] = []
        # trailing bytes of an opcode that was split across two DTX frames
        self._carry = b""

    async def _get_next_message(self):
        message = b""
        while message.startswith(b"bplist") or len(message) == 0:
            # ignore heartbeat messages
            message = await self.channel.receive_message()
        # an opcode (and its immediate words) may be split across frames; prepend the leftover
        self._set_current_message(self._carry + message)
        self._carry = b""

    def _set_current_message(self, message: bytes):
        self._message = BytesIO(message)

    def _seek_relative(self, offset: int):
        self._message.seek(offset, os.SEEK_CUR)

    def _peek_word(self) -> int:
        buf = self._message.read(2)
        if len(buf) != 2:
            raise EOFError()
        (word,) = struct.unpack("<H", buf)
        self._message.seek(-2, os.SEEK_CUR)
        return word

    def _read_word(self):
        word = self._peek_word()
        self._message.seek(2, os.SEEK_CUR)
        return word

    def _handle_push(self, word: int):
        assert word >> 14 in (0b10, 0b11), f"invalid magic for pushed item. word: {hex(word)}"

        count = 0
        imm = 0
        bit_count = 0
        while word >> 14 != 0b11:
            # not end word
            imm = (imm << 14) | (word & 0x3FFF)
            word = self._read_word()
            count += 1
            bit_count += 14

        imm = (imm << 14) | (word & 0x3FFF)
        bit_count += 14

        imm <<= 8 - bit_count % 8
        bit_count += 8 - bit_count % 8

        result = imm.to_bytes(math.ceil(bit_count / 8), "big")
        self.stack.append(result)

        return result

    def _handle_table_reset(self, word: int):
        """start new table vector"""
        self.generation += 1
        self.background = 0
        self.stack = []

    def _handle_sentinel(self, word: int):
        """push a dummy"""
        self.stack.append(None)

    def _handle_struct(self, word: int):
        """replace last `distance` items with a single one which represents them as a tuple"""
        distance = word & 0xFF

        if distance == 0xFF:
            raise NotImplementedError("long struct")

        new_item = self.stack[-distance:]

        self.stack = self.stack[:-distance]
        self.stack.append(new_item)

    def _handle_define_table(self, word: int):
        """define a table struct"""
        distance = 4

        table_raw = Table(*self.stack[-distance:])
        table = Table(
            # the raw table fields hold the undecoded bytes off the stack
            name=cast(bytes, table_raw.name).split(b"\x00", 1)[0].decode(),
            columns=[c.split(b"\x00", 1)[0].decode() for c in table_raw.columns],
            unknown0=table_raw.unknown0,
            unknown2=table_raw.unknown2,
        )

        self.stack = self.stack[:-distance]
        self.tables.append(table)

    def _handle_debug(self, word: int):
        """pop last pushed item from stack"""
        debug_id = word & 0xFF
        item = self.stack[-1]

        reference = int.from_bytes(item, byteorder="little")

        assert reference == len(self.stack) - 1, (
            f"assert debug {debug_id} got reference: {hex(reference)} instead of: {len(self.stack) - 1}  {item}"
        )
        self.stack = self.stack[:-1]

    def _handle_copy(self, word: int):
        """copy item at distance from stack"""
        distance = word & 0xFF
        if distance != 0xFF:
            item = self.stack[-distance - 1]
            self.stack.append(item)
        else:
            # long struct - pop distance from stack
            item = self.stack[-1]
            reference = int.from_bytes(item, byteorder="little") - 1
            self.stack = self.stack[:-1]
            self.stack.append(self.stack[reference])

    def _handle_end_row(self, word: int):
        """flush current row"""
        generation = word & 0xFF
        columns = self.tables[generation].columns
        row = self.stack[-len(columns) :]
        self.stack = self.stack[: -len(columns)]

        Message = dataclasses.make_dataclass("message", [c.replace("-", "_") for c in columns])
        message = Message(*row)
        message.process = 0 if message.process is None else struct.unpack("<I", message.process[0].ljust(4, b"\x00"))[0]
        message.thread = struct.unpack("<I", message.thread[0].ljust(4, b"\x00"))[0]

        string_fields = (
            "message_type",
            "format_string",
            "subsystem",
            "category",
            "sender_image_path",
            "event_type",
            "name",
        )
        for f in string_fields:
            if hasattr(message, f):
                v = getattr(message, f)
                setattr(message, f, decode_str(v) if v else v)

        if hasattr(message, "message"):
            return message

    def _handle_placeholder_count(self, word: int):
        """remove `count` last items from stack"""
        count = word & 0xFF
        if count > 0:
            self.stack = self.stack[:-count]

    def _handle_convert_mach_continuous(self, word: int):
        """push an item and pop it. effectively do nothing"""
        pass

    def _parse(self) -> Generator[Any, None, None]:
        operations: dict[int, Callable[[int], Any]] = {
            CMD_TABLE_RESET: self._handle_table_reset,
            CMD_SENTINEL: self._handle_sentinel,
            CMD_STRUCT: self._handle_struct,
            CMD_DEFINE_TABLE: self._handle_define_table,
            CMD_DEBUG: self._handle_debug,
            CMD_COPY: self._handle_copy,
            CMD_END_ROW: self._handle_end_row,
            CMD_PLACEHOLDER_COUNT: self._handle_placeholder_count,
            CMD_CONVERT_MACH_CONTINUOUS: self._handle_convert_mach_continuous,
        }

        while True:
            # remember where this opcode begins, in case the frame ends mid-opcode
            start = self._message.tell()
            try:
                word = self._read_word()
                opcode = word >> 8

                if opcode in operations:
                    result = operations[opcode](word)
                else:
                    self._handle_push(word)
                    result = None
            except EOFError:
                # the frame ended in the middle of an opcode (e.g. a multi-word push);
                # carry the remaining bytes over to the next frame instead of crashing
                self._message.seek(start)
                self._carry = self._message.read()
                break

            if opcode == CMD_END_ROW and result is not None:
                yield result

    async def __aiter__(self) -> AsyncGenerator[Any, None]:
        """
        Continuously receive frames and yield the decoded log entries they contain.

        :yields: A dynamically generated `message` dataclass per completed row, with fields named
            after the device-advertised table columns.
        """
        while True:
            await self._get_next_message()
            for message in self._parse():
                yield message
