from abc import ABC, abstractmethod
from base64 import b64decode
from typing import TYPE_CHECKING, Optional

from pymobiledevice3.services.web_protocol.automation_session import By

if TYPE_CHECKING:
    from pymobiledevice3.services.web_protocol.element import WebElement


class SeleniumApi(ABC):
    @abstractmethod
    async def find_element(self, by: By = By.ID, value: Optional[str] = None) -> "Optional[WebElement]":
        pass

    @abstractmethod
    async def find_elements(self, by: By = By.ID, value: Optional[str] = None) -> "list[WebElement]":
        pass

    @abstractmethod
    async def _get_screenshot_as_base64(self) -> str:
        pass

    async def find_element_by_class_name(self, name: str):
        return await self.find_element(By.CLASS_NAME, name)

    async def find_element_by_css_selector(self, css_selector: str):
        return await self.find_element(By.CSS_SELECTOR, css_selector)

    async def find_element_by_id(self, id_: str):
        return await self.find_element(value=id_)

    async def find_element_by_link_text(self, link_text: str):
        return await self.find_element(By.LINK_TEXT, link_text)

    async def find_element_by_name(self, name: str):
        return await self.find_element(By.NAME, name)

    async def find_element_by_partial_link_text(self, link_text: str):
        return await self.find_element(By.PARTIAL_LINK_TEXT, link_text)

    async def find_element_by_tag_name(self, name: str):
        return await self.find_element(By.TAG_NAME, name)

    async def find_element_by_xpath(self, xpath: str):
        return await self.find_element(By.XPATH, xpath)

    async def find_elements_by_class_name(self, name: str):
        return await self.find_elements(By.CLASS_NAME, name)

    async def find_elements_by_css_selector(self, css_selector: str):
        return await self.find_elements(By.CSS_SELECTOR, css_selector)

    async def find_elements_by_id(self, id_: str):
        return await self.find_elements(value=id_)

    async def find_elements_by_link_text(self, link_text: str):
        return await self.find_elements(By.LINK_TEXT, link_text)

    async def find_elements_by_name(self, name: str):
        return await self.find_elements(By.NAME, name)

    async def find_elements_by_partial_link_text(self, link_text: str):
        return await self.find_elements(By.PARTIAL_LINK_TEXT, link_text)

    async def find_elements_by_tag_name(self, name: str):
        return await self.find_elements(By.TAG_NAME, name)

    async def find_elements_by_xpath(self, xpath: str):
        return await self.find_elements(By.XPATH, xpath)

    async def screenshot(self, filename: str):
        png = await self.screenshot_as_png()
        try:
            with open(filename, "wb") as f:
                f.write(png)
        except OSError:
            return False
        return True

    async def screenshot_as_png(self) -> bytes:
        return b64decode((await self._get_screenshot_as_base64()).encode("ascii"))

    async def get_screenshot_as_base64(self) -> str:
        return await self._get_screenshot_as_base64()

    async def get_screenshot_as_file(self, filename: str):
        return await self.screenshot(filename)

    async def get_screenshot_as_png(self):
        return await self.screenshot_as_png()

    async def save_screenshot(self, filename: str) -> bool:
        return await self.screenshot(filename)
