################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the TCP Eol (End of Option List) option support code.

pmd_net_proto/protocols/tcp/options/tcp__option__eol.py

ver 3.0.7
"""

from __future__ import annotations

from dataclasses import field
from pmd_net_proto._compat import dataclass
from typing_extensions import Self, override

from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.protocols.tcp.options.tcp__option import TcpOption, TcpOptionType

# The TCP Eol (End of Option List) option [RFC 9293 §3.2].

# +-+-+-+-+-+-+-+-+
# |    Type = 0   |
# +-+-+-+-+-+-+-+-+

TCP__OPTION__EOL__LEN = 1
TCP__OPTION__EOL__STRUCT = "! B"


@dataclass(frozen=True, kw_only=False, slots=True)
class TcpOptionEol(TcpOption):
    """
    The TCP Eol (End of Option List) option support class.
    """

    type: TcpOptionType = field(
        repr=False,
        init=False,
        default=TcpOptionType.EOL,
    )
    len: int = field(
        repr=False,
        init=False,
        default=TCP__OPTION__EOL__LEN,
    )

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the TCP Eol option fields.
        """

    @override
    def __str__(self) -> str:
        """
        Get the TCP Eol option log string.
        """

        return "eol"

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the TCP Eol option as a memoryview.
        """

        return memoryview(bytearray(bytes(self.type)))
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the TCP Eol option from buffer.
        """

        assert (
            value := len(buffer)
        ) >= TCP__OPTION__EOL__LEN, (
            f"The minimum length of the TCP Eol option must be {TCP__OPTION__EOL__LEN} byte. Got: {value!r}"
        )

        assert (value := buffer[0]) == int(
            TcpOptionType.EOL
        ), f"The TCP Eol option type must be {TcpOptionType.EOL!r}. Got: {TcpOptionType.from_int(value)!r}"

        return cls()
