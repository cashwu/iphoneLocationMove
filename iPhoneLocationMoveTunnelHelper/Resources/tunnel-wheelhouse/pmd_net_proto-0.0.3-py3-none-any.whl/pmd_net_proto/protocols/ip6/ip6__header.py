################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the IPv6 packet header.

pmd_net_proto/protocols/ip6/ip6__header.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from abc import ABC
from dataclasses import field
from pmd_net_proto._compat import dataclass
from typing_extensions import Self, override

from pmd_net_addr import Ip6Address, IpVersion
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.enums import IpProto
from pmd_net_proto.lib.int_checks import (
    UINT_16__MAX,
    is_uint2,
    is_uint6,
    is_uint8,
    is_uint16,
    is_uint20,
)
from pmd_net_proto.lib.proto_struct import ProtoStruct

# The IPv6 packet header [RFC 8200].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |Version|   DSCP    |ECN|           Flow Label                  |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |         Payload Length        |  Next Header  |   Hop Limit   |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               >
# +                                                               +
# >                                                               >
# +                         Source Address                        +
# >                                                               >
# +                                                               +
# >                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               >
# +                                                               +
# >                                                               >
# +                      Destination Address                      +
# >                                                               >
# +                                                               +
# >                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

IP6__HEADER__LEN = 40
IP6__HEADER__STRUCT = "! L HBB 16s 16s"
IP6__PAYLOAD__MAX_LEN = UINT_16__MAX
IP6__DEFAULT_HOP_LIMIT = 64
IP6__MIN_MTU = 1280  # RFC 8200

# Byte offsets of selected header fields, used as the ICMPv6
# Parameter Problem 'pointer' value when the parser raises
# Ip6SanityError on a field-level violation (RFC 4443 §3.4 /
# RFC 1122 §3.2.2.5).
IP6__POINTER__HOP = 7
IP6__POINTER__SRC = 8  # Source Address (16 bytes; pointer = first byte)


@dataclass(frozen=True, kw_only=True, slots=True)
class Ip6Header(ProtoStruct):
    """
    The IPv6 packet header.
    """

    ver: IpVersion = field(
        repr=False,
        init=False,
        default=IpVersion.IP6,
    )
    dscp: int
    ecn: int
    flow: int
    dlen: int
    next: IpProto
    hop: int
    src: Ip6Address
    dst: Ip6Address

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the Ip6 header fields.
        """

        assert is_uint6(self.dscp), f"The 'dscp' field must be a 6-bit unsigned integer. Got: {self.dscp!r}"

        assert is_uint2(self.ecn), f"The 'ecn' field must be a 2-bit unsigned integer. Got: {self.ecn!r}"

        assert is_uint20(self.flow), f"The 'flow' field must be a 20-bit unsigned integer. Got: {self.flow!r}"

        assert is_uint16(self.dlen), f"The 'dlen' field must be a 16-bit unsigned integer. Got: {self.dlen!r}"

        assert isinstance(self.next, IpProto), f"The 'next' field must be an IpProto. Got: {type(self.next)!r}"

        assert is_uint8(self.hop), f"The 'hop' field must be an 8-bit unsigned integer. Got: {self.hop!r}"

        assert isinstance(self.src, Ip6Address), f"The 'src' field must be an Ip6Address. Got: {type(self.src)!r}"

        assert isinstance(self.dst, Ip6Address), f"The 'dst' field must be an Ip6Address. Got: {type(self.dst)!r}"

    @override
    def __len__(self) -> int:
        """
        Get the IPv6 header length.
        """

        return IP6__HEADER__LEN

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the IPv6 header as a memoryview.
        """

        struct.pack_into(
            IP6__HEADER__STRUCT,
            buffer := bytearray(len(self)),
            0,
            int(self.ver) << 28 | self.dscp << 22 | self.ecn << 20 | self.flow,
            self.dlen,
            int(self.next),
            self.hop,
            bytes(self.src),
            bytes(self.dst),
        )

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the IPv6 header from buffer.
        """

        ver__dscp__ecn__flow, dlen, next, hop, src, dst = struct.unpack(IP6__HEADER__STRUCT, buffer[:IP6__HEADER__LEN])

        return cls(
            dscp=(ver__dscp__ecn__flow >> 22) & 0b00111111,
            ecn=(ver__dscp__ecn__flow >> 20) & 0b00000011,
            flow=ver__dscp__ecn__flow & 0b00000000_00001111_11111111_11111111,
            dlen=dlen,
            next=IpProto.from_int(next),
            hop=hop,
            src=Ip6Address(src),
            dst=Ip6Address(dst),
        )


class Ip6HeaderProperties(ABC):
    """
    Properties used to access the IPv6 header fields.
    """

    _header: Ip6Header

    @property
    def ver(self) -> IpVersion:
        """
        Get the IPv6 header 'ver' field.
        """

        return IpVersion(self._header.ver)

    @property
    def dscp(self) -> int:
        """
        Get the IPv6 header 'dscp' field.
        """

        return self._header.dscp

    @property
    def ecn(self) -> int:
        """
        Get the IPv6 header 'ecn' field.
        """

        return self._header.ecn

    @property
    def flow(self) -> int:
        """
        Get the IPv6 header 'flow' field.
        """

        return self._header.flow

    @property
    def dlen(self) -> int:
        """
        Get the IPv6 header 'dlen' field.
        """

        return self._header.dlen

    @property
    def next(self) -> IpProto:
        """
        Get the IPv6 header 'next' field.
        """

        return self._header.next

    @property
    def hop(self) -> int:
        """
        Get the IPv6 header 'hop' field.
        """

        return self._header.hop

    @property
    def src(self) -> Ip6Address:
        """
        Get the IPv6 header 'src' field.
        """

        return self._header.src

    @property
    def dst(self) -> Ip6Address:
        """
        Get the IPv6 header 'dst' field.
        """

        return self._header.dst
