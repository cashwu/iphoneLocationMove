################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the SNAP packet assembler. PyTCP does
not currently generate 802.3+LLC+SNAP outbound traffic (TX
path is Ethernet II only); the assembler is provided for
round-trip testing.

pmd_net_proto/protocols/snap/snap__assembler.py

ver 3.0.7
"""

from __future__ import annotations

from typing_extensions import override

from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.proto_assembler import ProtoAssembler
from pmd_net_proto.lib.tracker import Tracker
from pmd_net_proto.protocols.snap.snap__base import Snap
from pmd_net_proto.protocols.snap.snap__header import SnapHeader
from pmd_net_proto._compat import as_buffer


class SnapAssembler(Snap, ProtoAssembler):
    """
    The SNAP packet assembler.
    """

    def __init__(
        self,
        *,
        snap__oui: int = 0,
        snap__pid: int = 0,
        snap__payload: Buffer = bytes(),
        echo_tracker: Tracker | None = None,
    ) -> None:
        """
        Initialize the SNAP packet assembler.
        """

        self._tracker: Tracker = Tracker(prefix="TX", echo_tracker=echo_tracker)
        self._payload = snap__payload
        self._header = SnapHeader(
            oui=snap__oui,
            pid=snap__pid,
        )

    @override
    def assemble(self, buffers: list[Buffer], /) -> None:
        """
        Assemble the SNAP packet into list of buffers.
        """

        buffers.append(as_buffer(bytearray(as_buffer(self._header))))
        buffers.append(as_buffer(self._payload))
