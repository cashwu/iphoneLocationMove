################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the ICMPv6 ND Neighbor Solicitation message support class.

pmd_net_proto/protocols/icmp6/message/nd/icmp6__nd__message__neighbor_solicitation.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from dataclasses import field
from pmd_net_proto._compat import as_buffer, dataclass
from typing_extensions import Self, override

from pmd_net_addr import Ip6Address
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.int_checks import is_uint16
from pmd_net_proto.protocols.icmp6.icmp6__errors import (
    Icmp6IntegrityError,
    Icmp6SanityError,
)
from pmd_net_proto.protocols.icmp6.message.icmp6__message import (
    Icmp6Code,
    Icmp6Type,
)
from pmd_net_proto.protocols.icmp6.message.nd.icmp6__nd__message import (
    Icmp6NdMessage,
)
from pmd_net_proto.protocols.icmp6.message.nd.option.icmp6__nd__options import (
    Icmp6NdOptions,
)

# The ICMPv6 ND Neighbor Solicitation message (135/0) [RFC 4861].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |     Type      |     Code      |          Checksum             |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                           Reserved                            |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               >
# +                                                               +
# >                                                               >
# +                       Target Address                          +
# >                                                               >
# +                                                               +
# >                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# ~                                                               ~
# ~                          Options                              ~
# ~                                                               ~
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


ICMP6__ND__NEIGHBOR_SOLICITATION__LEN = 24
ICMP6__ND__NEIGHBOR_SOLICITATION__STRUCT = "! BBH L 16s"


class Icmp6NdNeighborSolicitationCode(Icmp6Code):
    """
    The ICMPv6 ND Neighbor Solicitation 'code' field values.
    """

    DEFAULT = 0  # RFC 4861 §4.3: only code 0 defined.


@dataclass(frozen=True, kw_only=True, slots=True)
class Icmp6NdMessageNeighborSolicitation(Icmp6NdMessage):
    """
    The ICMPv6 ND Neighbor Solicitation message.
    """

    type: Icmp6Type = field(
        repr=False,
        init=False,
        default=Icmp6Type.ND__NEIGHBOR_SOLICITATION,
    )
    code: Icmp6NdNeighborSolicitationCode = Icmp6NdNeighborSolicitationCode.DEFAULT
    cksum: int = 0

    target_address: Ip6Address
    options: Icmp6NdOptions

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the ICMPv6 ND Neighbor Solicitation message fields.
        """

        assert isinstance(
            self.code, Icmp6NdNeighborSolicitationCode
        ), f"The 'code' field must be an Icmp6NdNeighborSolicitationCode. Got: {type(self.code)!r}"

        assert is_uint16(self.cksum), f"The 'cksum' field must be a 16-bit unsigned integer. Got: {self.cksum!r}"

        assert isinstance(
            self.target_address, Ip6Address
        ), f"The 'target_address' field must be an Ip6Address. Got: {type(self.target_address)!r}"

        assert isinstance(
            self.options, Icmp6NdOptions
        ), f"The 'options' field must be an Icmp6NdOptions. Got: {type(self.options)!r}"

    @override
    def __len__(self) -> int:
        """
        Get the ICMPv6 ND Neighbor Solicitation message length.
        """

        return ICMP6__ND__NEIGHBOR_SOLICITATION__LEN + len(self.options)

    @override
    def __str__(self) -> str:
        """
        Get the ICMPv6 ND Neighbor Solicitation message log string.
        """

        return (
            "ICMPv6 ND Neighbor Solicitation, "
            f"target {self.target_address}, "
            f"{f'opts [{self.options}], ' if self.options else ''}"
            f"len {len(self)} ({ICMP6__ND__NEIGHBOR_SOLICITATION__LEN}+"
            f"{len(self.options)})"
        )

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the ICMPv6 ND Neighbor Solicitation message as a memoryview.
        """

        buffer = self._pack_header(len(self))
        buffer[ICMP6__ND__NEIGHBOR_SOLICITATION__LEN:] = bytearray(as_buffer(self.options))

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    def _pack_header(
        self,
        buffer_len: int = ICMP6__ND__NEIGHBOR_SOLICITATION__LEN,
        /,
    ) -> bytearray:
        """
        Get the ICMPv6 ND Neighbor Solicitation message as bytes.
        """

        struct.pack_into(
            ICMP6__ND__NEIGHBOR_SOLICITATION__STRUCT,
            buffer := bytearray(as_buffer(buffer_len)),
            0,
            int(self.type),
            int(self.code),
            0,
            0,
            bytes(self.target_address),
        )

        return buffer

    @override
    def validate_sanity(self, *, ip6__hop: int, ip6__src: Ip6Address, ip6__dst: Ip6Address) -> None:
        """
        Ensure sanity of the ICMPv6 ND Neighbor Solicitation message after parsing it.
        """

        # RFC 4861 §4.3 — the Neighbor Solicitation 'Code' field is 0.
        if self.code.is_unknown:
            raise Icmp6SanityError(
                f"The 'code' field of the ICMPv6 ND Neighbor Solicitation message "
                f"must be one of {Icmp6NdNeighborSolicitationCode.get_known_values()}. "
                f"Got: {int(self.code)}."
            )

        if ip6__hop != 255:
            raise Icmp6SanityError(
                f"ND Neighbor Solicitation - [RFC 4861] The 'ip6__hop' field must be 255. Got: {ip6__hop!r}",
            )

        if not (ip6__src.is_unicast or ip6__src.is_unspecified):
            raise Icmp6SanityError(
                "ND Neighbor Solicitation - [RFC 4861] The 'ip6__src' address must be unicast or unspecified. "
                f"Got: {ip6__src!r}",
            )

        if ip6__dst not in {
            self.target_address,
            self.target_address.solicited_node_multicast,
        }:
            raise Icmp6SanityError(
                "ND Neighbor Solicitation - [RFC 4861] The 'ip6__dst' address must be the same as "
                f"'target_address' address or related solicited-node multicast address. Got: {ip6__dst!r}",
            )

        if not self.target_address.is_unicast:
            raise Icmp6SanityError(
                "ND Neighbor Solicitation - [RFC 4861] The 'target_address' address must be unicast. "
                f"Got: {self.target_address!r}",
            )

        if ip6__src.is_unspecified:
            if ip6__dst != self.target_address.solicited_node_multicast:
                raise Icmp6SanityError(
                    "ND Neighbor Solicitation - [RFC 4861] When the 'ip6__src' is unspecified, "
                    "the 'ip6__dst' must be the solicited-node multicast of 'target_address'. "
                    f"Got: {ip6__dst!r}",
                )
            if self.slla is not None:
                raise Icmp6SanityError(
                    "ND Neighbor Solicitation - [RFC 4861] When the 'ip6__src' is unspecified, the 'slla' option "
                    f"must not be included. Got: {self.slla!r}",
                )

        # RFC 4861 §7.1.1: the receiver-side option-presence MUSTs are
        # fully enforced — every option has length > 0
        # ('Icmp6NdOptions.validate_integrity') and, above, the
        # unspecified-source => no-SLLA rule. Options not specified for
        # Neighbor Solicitation "MUST be ignored and the packet processed
        # as normal", so no further presence check is added here.

    @override
    @staticmethod
    def validate_integrity(*, frame: Buffer, ip6__dlen: int) -> None:
        """
        Ensure integrity of the ICMPv6 ND Neighbor Solicitation message before parsing it.
        """

        if not (ICMP6__ND__NEIGHBOR_SOLICITATION__LEN <= ip6__dlen <= len(frame)):
            raise Icmp6IntegrityError(
                "The condition 'ICMP6__ND__NEIGHBOR_SOLICITATION__LEN <= ip6__dlen <= len(frame)' must be met. "
                f"Got: {ICMP6__ND__NEIGHBOR_SOLICITATION__LEN=}, {ip6__dlen=}, {len(frame)=}"
            )

        Icmp6NdOptions.validate_integrity(
            frame=frame,
            offset=ICMP6__ND__NEIGHBOR_SOLICITATION__LEN,
        )

    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the ICMPv6 ND Neighbor Solicitation message from buffer.
        """

        type_, code, cksum, _, target_address = struct.unpack(
            ICMP6__ND__NEIGHBOR_SOLICITATION__STRUCT,
            buffer[:ICMP6__ND__NEIGHBOR_SOLICITATION__LEN],
        )

        assert (received_type := Icmp6Type.from_int(type_)) == (
            valid_type := Icmp6Type.ND__NEIGHBOR_SOLICITATION
        ), f"The 'type' field must be {valid_type!r}. Got: {received_type!r}"

        return cls(
            code=Icmp6NdNeighborSolicitationCode.from_int(code),
            cksum=cksum,
            target_address=Ip6Address(target_address),
            options=Icmp6NdOptions.from_buffer(buffer[ICMP6__ND__NEIGHBOR_SOLICITATION__LEN:]),
        )

    @override
    def assemble(self, buffers: list[Buffer], /) -> None:
        """
        Assemble the ICMPv6 ND Neighbor Solicitation message into the buffer list.
        """

        buffers.append(as_buffer(self._pack_header()))
        buffers.append(as_buffer(bytearray(as_buffer(self.options))))
