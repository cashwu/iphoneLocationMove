################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the PyTCP daemon run loop.

'run_daemon' is a coroutine ('docs/refactor/pure_asyncio.md') that boots
the in-process stack (init -> add one interface -> await start), brings
up the AF_UNIX control server so out-of-process 'pmd_pytcp.client' consumers
can open sockets and drive the control APIs, and then waits until
SIGINT / SIGTERM, tearing the IPC server and the stack back down on the
way out. The '__main__' CLI drives it with 'asyncio.run'. Signals are
wired through 'loop.add_signal_handler', with a portable
'signal.signal' fallback (marshalling back onto the loop via
'call_soon_threadsafe') for platforms whose loop lacks signal-handler
support. 'default_socket_path' is the canonical control socket location
('$XDG_RUNTIME_DIR/pmd_pytcp.sock', falling back to the system temp dir).
Readiness is reported through an 'on_ready' callback so the run loop
stays output-free and testable; the '__main__' CLI prints it.

pmd_pytcp/daemon/daemon.py

ver 3.0.7
"""

from __future__ import annotations

import asyncio
import os
import signal
import tempfile
from collections.abc import Callable
from typing import Any

from pmd_net_addr import Ip4IfAddr, Ip6IfAddr, MacAddress
from pmd_pytcp import stack
from pmd_pytcp.ipc.ipc__server import IpcServer

IPC__DAEMON__SOCKET_NAME: str = "pmd_pytcp.sock"


def default_socket_path() -> str:
    """
    Return the canonical daemon control-socket path —
    '$XDG_RUNTIME_DIR/pmd_pytcp.sock' when the runtime dir is set, else the
    system temp dir (Linux 'ip'-tooling convention for a per-user runtime
    control endpoint).
    """

    runtime_dir = os.environ.get("XDG_RUNTIME_DIR")
    base = runtime_dir if runtime_dir else tempfile.gettempdir()
    return os.path.join(base, IPC__DAEMON__SOCKET_NAME)


def _resolve_interface(interface_name: str, *, mac_address: MacAddress | None) -> dict[str, Any]:
    """
    Resolve the 'add_interface' kwargs for one interface name, dispatching
    on the 'tap' / 'tun' prefix.
    """

    _match_subject = interface_name[:3]
    if _match_subject == "tap":
        return stack.initialize_interface__tap(interface_name=interface_name, mac_address=mac_address)
    elif _match_subject == "tun":
        return stack.initialize_interface__tun(interface_name=interface_name)

    raise ValueError(f"Unsupported interface type {interface_name[:3]!r}; only 'tap' and 'tun' are supported.")


def _install_signal_handlers(stop: asyncio.Event, /) -> "list[signal.Signals]":
    """
    Arm SIGINT / SIGTERM to set the stop event. Prefers the loop's
    'add_signal_handler' (delivery lands directly on the loop); falls
    back to 'signal.signal' with a 'call_soon_threadsafe' trampoline on
    platforms whose loop lacks signal-handler support (e.g. the Windows
    proactor). Returns the signals armed via the loop so the caller can
    disarm them on the way out.
    """

    loop = asyncio.get_running_loop()
    armed: list[signal.Signals] = []

    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(signum, stop.set)
            armed.append(signum)
        except (NotImplementedError, RuntimeError):

            def _on_signal(_signum: int, _frame: object, /) -> None:
                loop.call_soon_threadsafe(stop.set)

            signal.signal(signum, _on_signal)

    return armed


async def run_daemon(
    *,
    socket_path: str,
    interface_name: str = "tap7",
    mac_address: MacAddress | None = None,
    ip4_support: bool = True,
    ip4_host: Ip4IfAddr | None = None,
    ip6_support: bool = True,
    ip6_host: Ip6IfAddr | None = None,
    on_ready: Callable[[str], None] | None = None,
) -> None:
    """
    Run the PyTCP daemon: boot the stack on one interface, serve the
    AF_UNIX control socket, and wait until SIGINT / SIGTERM.

    With no explicit host address a NIC autoconfigures (DHCPv4 for IPv4,
    SLAAC for IPv6). 'on_ready', if given, is called with 'socket_path'
    once the control server is listening.
    """

    stack.init()
    interface_args = _resolve_interface(interface_name, mac_address=mac_address)
    stack.add_interface(
        **interface_args,
        ip4_support=ip4_support,
        ip4_host=ip4_host,
        ip4_dhcp=ip4_support and ip4_host is None,
        ip6_support=ip6_support,
        ip6_host=ip6_host,
        ip6_gua_autoconfig=ip6_support and ip6_host is None,
    )
    await stack.start()

    server = IpcServer(socket_path=socket_path)
    await server.start()

    if on_ready is not None:
        on_ready(socket_path)

    stop = asyncio.Event()
    armed_signals = _install_signal_handlers(stop)

    try:
        await stop.wait()
    finally:
        loop = asyncio.get_running_loop()
        for signum in armed_signals:
            loop.remove_signal_handler(signum)
        server.stop()
        await server.wait_stopped()
        await stack.stop()
