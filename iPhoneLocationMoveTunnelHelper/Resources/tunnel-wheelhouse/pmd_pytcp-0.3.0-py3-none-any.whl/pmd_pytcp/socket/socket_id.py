################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the class representing the Socket identifier.

pmd_pytcp/socket/socket_id.py

ver 3.0.7
"""

from __future__ import annotations

from pmd_pytcp._compat import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pmd_net_addr import IpAddress
    from pmd_pytcp.socket import AddressFamily, SocketType


@dataclass(frozen=True, kw_only=True, slots=True)
class SocketId:
    """
    The Socket identifier.
    """

    address_family: AddressFamily
    socket_type: SocketType
    local_address: IpAddress
    local_port: int
    remote_address: IpAddress
    remote_port: int
