################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the IPv4 multicast source-filter value type and the
RFC 3376 §3.2 per-interface state merge. A filter is a mode
(INCLUDE / EXCLUDE) plus a source set; the merge derives the per-interface
reception state from the set of per-socket filters.

pmd_pytcp/lib/ip4_multicast_filter.py

ver 3.0.7
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import field
from pmd_pytcp._compat import dataclass
from enum import Enum, auto

from pmd_net_addr import Ip4Address


class Ip4MulticastFilterMode(Enum):
    """
    The IPv4 multicast source-filter mode (RFC 3376 §3.1). INCLUDE
    listens only to the listed sources; EXCLUDE listens to every source
    except the listed ones (so EXCLUDE{} is an any-source join).
    """

    INCLUDE = auto()
    EXCLUDE = auto()


@dataclass(frozen=True, slots=True)
class Ip4MulticastFilter:
    """
    An IPv4 multicast source filter — a mode plus a source set. The
    per-socket filter (RFC 3376 §3.1) and the merged per-interface filter
    (§3.2) share this shape.
    """

    mode: Ip4MulticastFilterMode
    sources: frozenset[Ip4Address] = field(default=frozenset())

    @property
    def has_reception(self) -> bool:
        """
        Get whether the filter represents any reception state. Every
        EXCLUDE filter receives (EXCLUDE{} is any-source); an INCLUDE
        filter receives only when its source set is non-empty — INCLUDE{}
        is the "not a member" state (RFC 3376 §3.2).
        """

        return self.mode is Ip4MulticastFilterMode.EXCLUDE or bool(self.sources)

    def allows(self, source: Ip4Address, /) -> bool:
        """
        Get whether a datagram from 'source' passes this filter for
        delivery (RFC 3376 §3.1): an INCLUDE filter delivers only its
        listed sources, an EXCLUDE filter delivers every source except
        its listed ones. This is the data-plane source-delivery gate
        (Linux 'ip_mc_sf_allow').
        """

        if self.mode is Ip4MulticastFilterMode.INCLUDE:
            return source in self.sources
        return source not in self.sources

    @classmethod
    def merge(cls, filters: Iterable[Ip4MulticastFilter], /) -> Ip4MulticastFilter:
        """
        Merge the per-socket 'filters' into the per-interface filter per
        RFC 3376 §3.2: if any filter is EXCLUDE the interface is EXCLUDE
        with the intersection of the EXCLUDE source lists minus the union
        of the INCLUDE source lists; otherwise the interface is INCLUDE
        with the union of the INCLUDE source lists. Merging no filters
        yields INCLUDE{} (no reception).
        """

        include_sources: set[Ip4Address] = set()
        exclude_lists: list[frozenset[Ip4Address]] = []

        for filter_ in filters:
            if filter_.mode == Ip4MulticastFilterMode.INCLUDE:
                include_sources |= filter_.sources
            elif filter_.mode == Ip4MulticastFilterMode.EXCLUDE:
                exclude_lists.append(filter_.sources)

        if exclude_lists:
            excluded = set(exclude_lists[0]).intersection(*exclude_lists[1:])
            excluded -= include_sources
            return cls(mode=Ip4MulticastFilterMode.EXCLUDE, sources=frozenset(excluded))

        return cls(mode=Ip4MulticastFilterMode.INCLUDE, sources=frozenset(include_sources))
