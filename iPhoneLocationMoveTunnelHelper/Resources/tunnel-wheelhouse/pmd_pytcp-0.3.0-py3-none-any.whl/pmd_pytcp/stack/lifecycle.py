################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
Stack lifecycle module — owns the init / start / stop /
mock__init entry points. Extracted from
'pmd_pytcp/stack/__init__.py' (Phase 2 of the directory restructure
at 'docs/refactor/pytcp_directory_restructure.md') so the
sibling 'pmd_pytcp/stack/__init__.py' shrinks to constants +
singleton declarations + interface helpers.

The lifecycle functions read and write the module-level
singletons that still live on 'pmd_pytcp.stack' via
'import pmd_pytcp.stack as _stack; _stack.X = Y'. Same pattern
the test harness uses for snapshot/restore.

pmd_pytcp/stack/lifecycle.py

ver 3.0.7
"""

from __future__ import annotations

from typing import Any

from pmd_net_addr import (
    Ip4Address,
    Ip4IfAddr,
    Ip4Network,
    Ip6Address,
    Ip6IfAddr,
    Ip6Network,
    MacAddress,
)
from pmd_pytcp.lib.interface_layer import InterfaceLayer
from pmd_pytcp.lib.logger import log, refresh_log_enabled
from pmd_pytcp.lib.packet_stats import LinkStatsCounters, PacketStatsRx, PacketStatsTx
from pmd_pytcp.protocols.arp.arp__cache import ArpCache
from pmd_pytcp.protocols.dhcp4.dhcp4__client import Dhcp4Client
from pmd_pytcp.protocols.dhcp6.dhcp6__client import Dhcp6Client
from pmd_pytcp.protocols.icmp6.nd.nd__cache import NdCache
from pmd_pytcp.protocols.ip4.acd.ip4_acd import Ip4Acd
from pmd_pytcp.runtime.fib import RouteTable
from pmd_pytcp.runtime.interface_table import InterfaceTable
from pmd_pytcp.runtime.packet_handler import PacketHandlerL2, PacketHandlerL3
from pmd_pytcp.runtime.rx_ring import RxRing
from pmd_pytcp.runtime.timer import Timer
from pmd_pytcp.runtime.tx_ring import TxRing
from pmd_pytcp.socket import AddressFamily
from pmd_pytcp.stack.address import AddressApi
from pmd_pytcp.stack.link import LinkApi
from pmd_pytcp.stack.membership import MembershipApi
from pmd_pytcp.stack.neighbor import NeighborApi
from pmd_pytcp.stack.route import RouteApi, install_boot_default_routes


def mock__init(
    *,
    mock__timer: Timer | None = None,
    mock__tx_ring: TxRing | None = None,
    mock__rx_ring: RxRing | None = None,
    mock__arp_cache: ArpCache | None = None,
    mock__nd_cache: NdCache | None = None,
    mock__packet_handler: PacketHandlerL2 | None = None,
    mock__address: AddressApi | None = None,
    mock__link: LinkApi | None = None,
    mock__route: RouteApi | None = None,
    mock__dhcp4_client: Dhcp4Client | None = None,
    mock__dhcp6_client: Dhcp6Client | None = None,
) -> None:
    """
    Initialize stack components for unit testing.
    """

    import pmd_pytcp.stack as _stack

    # Reset the Link API running flag per test so it does not
    # leak from a prior test that called 'stack.start()'. The
    # unit test corpus does not normally call start/stop, so
    # the default 'False' is the right reset value.
    _stack.stack_running = False

    if mock__timer is not None:
        _stack.timer = mock__timer

    if mock__packet_handler is not None:
        # Inject the RX / TX rings into the handler the same way the
        # real 'init()' does, so a test exercising the loop /
        # send-out paths through 'mock__init' dequeues from / enqueues
        # onto the handler's own rings. Harness tests that drive RX via
        # '_phrx_ethernet' directly don't pass 'mock__rx_ring' and leave
        # that None; the TX harness passes 'mock__tx_ring' and asserts on
        # its recorded frames.
        if mock__rx_ring is not None:
            mock__packet_handler._rx_ring = mock__rx_ring
        if mock__tx_ring is not None:
            mock__packet_handler._tx_ring = mock__tx_ring
        # Bind the per-interface neighbor caches to the handler the
        # same way 'init()' does (both directions), so the RX/TX
        # cache lookups go through 'self._{arp,nd}_cache' and the
        # caches' solicit / flush callbacks route back through the
        # owning handler rather than the global shims.
        if mock__arp_cache is not None:
            mock__packet_handler._arp_cache = mock__arp_cache
            mock__arp_cache._owner = mock__packet_handler
        if mock__nd_cache is not None:
            mock__packet_handler._nd_cache = mock__nd_cache
            mock__nd_cache._owner = mock__packet_handler
        # Register the handler in the per-ifindex interface registry
        # keyed by its own '_ifindex' (default 1 for the harness's
        # sole interface). Only when a handler is passed — a
        # timer-only 'mock__init' (e.g. IcmpTestCase's second call)
        # must NOT wipe the registry the first call populated. Rebuild
        # the table fresh (same reconstruct-per-test lifecycle as the
        # FIBs below) and place the handler at its own ifindex.
        _interfaces = InterfaceTable(first_ifindex=_stack.STACK__DEFAULT_IFINDEX)
        _interfaces[mock__packet_handler._ifindex] = mock__packet_handler
        _stack.interfaces = _interfaces

    # Phase 4 commit A — the Address API. If the test harness
    # passes a packet_handler, also build a default Address API
    # over it (tests that need to mock the API itself can pass
    # 'mock__address' explicitly).
    if mock__address is not None:
        _stack.address = mock__address
    elif mock__packet_handler is not None:
        _stack.address = AddressApi(packet_handler=mock__packet_handler)

    # Link API Phase 0 — same pattern as 'address'. Tests get a
    # default 'LinkApi' bound to the mocked packet handler so
    # consumer code reading 'stack.link.mac_address' works in
    # isolation without bespoke harness wiring.
    if mock__link is not None:
        _stack.link = mock__link
    elif mock__packet_handler is not None:
        _stack.link = LinkApi(packet_handler=mock__packet_handler)

    # Neighbor API — same pattern as 'address' / 'link'. A default
    # 'NeighborApi' bound to the mocked handler lets consumer code
    # reading 'stack.neighbor.*' work in isolation without bespoke
    # harness wiring.
    if mock__packet_handler is not None:
        _stack.neighbor = NeighborApi(packet_handler=mock__packet_handler)

    # Membership API — same pattern as 'address' / 'link' /
    # 'neighbor'. A default 'MembershipApi' bound to the mocked
    # handler lets consumer code reading 'stack.membership.*' work in
    # isolation without bespoke harness wiring.
    if mock__packet_handler is not None:
        _stack.membership = MembershipApi(packet_handler=mock__packet_handler)

    # Host-mode routing table — Phase 1. Rebuild the two FIBs
    # fresh every 'mock__init' (i.e. every harness 'setUp') so
    # route state cannot leak across the suite; same reconstruct-
    # per-test lifecycle as 'timer' / 'address' / 'link', which
    # is why the FIBs need no snapshot/restore entry. The
    # integration harness installs the fixture default routes
    # after this call; unit tests get clean empty FIBs.
    ip4_fib: RouteTable[Ip4Address, Ip4Network] = RouteTable()
    ip6_fib: RouteTable[Ip6Address, Ip6Network] = RouteTable()
    _stack.ip4_fib = ip4_fib
    _stack.ip6_fib = ip6_fib
    if mock__route is not None:
        _stack.route = mock__route
    else:
        _stack.route = RouteApi(ip4_fib=ip4_fib, ip6_fib=ip6_fib)

    # Inject the routing-control API into every registered interface the
    # same way 'init()' does, so the RX RA path drives the default route
    # through 'self._route_api'. 'mock__init' rebuilds 'stack.route' on
    # EVERY call (e.g. 'IcmpTestCase' calls it a second time, timer-only),
    # so re-inject into whatever interfaces are currently registered — not
    # just the one passed this call — otherwise a handler keeps a stale
    # RouteApi wrapping the previous FIBs.
    for _registered_handler in _stack.interfaces.values():
        _registered_handler._route_api = _stack.route

    # Phase 4 commit B — DHCPv4 lifecycle. Default to None unless
    # the harness explicitly opts in; existing tests (NetworkTestCase
    # et al.) don't exercise the lifecycle and don't need a fake.
    _stack.dhcp4_client = mock__dhcp4_client
    # DHCPv6 lifecycle (RFC 8415). Default None — the harness opts in
    # via 'mock__dhcp6_client'; the RA-trigger integration tests inject
    # a client directly on the packet handler instead.
    _stack.dhcp6_client = mock__dhcp6_client

    # RFC 3927 Phase 1 — link-local autoconfig client slot. Default
    # None for unit tests; the link-local subsystem is exercised
    # through its own unit tests, not through the integration
    # harness in Phase 1.
    _stack.link_local = None


def add_interface(
    *,
    fd: int,
    layer: InterfaceLayer,
    mtu: int = 1500,
    mac_address: MacAddress | None = None,
    interface_name: str | None = None,
    ip4_support: bool = True,
    ip4_host: Ip4IfAddr | None = None,
    ip4_dhcp: bool = False,
    ip4_link_local: bool = False,
    ip6_support: bool = True,
    ip6_host: Ip6IfAddr | None = None,
    ip6_gua_autoconfig: bool = False,
    ip6_lla_autoconfig: bool = True,
) -> int:
    """
    Construct one network interface — its fd-bound RX / TX rings,
    its per-ifindex neighbor cache(s) and its packet handler —
    register it in 'stack.interfaces' under a freshly allocated
    ifindex, and return that ifindex.

    The handler instance IS the interface: it owns the injected
    rings and the ARP / ND caches (Linux keys neighbors per
    ifindex). The first interface added takes 'STACK__DEFAULT_IFINDEX'
    and also populates the N=1 back-compat singletons
    'stack.packet_handler' / 'rx_ring' / 'tx_ring' / 'arp_cache' /
    'nd_cache' (retired in a later phase); subsequent interfaces get
    the next free index and leave those shims on the boot interface.

    'init()' calls this once for the boot interface; the runtime
    multi-interface path calls it again once N>1 is enabled.
    """

    import pmd_pytcp.stack as _stack

    # Per-interface stats — each interface's rings + handler share
    # one set, so ring drop counters and per-protocol counters land
    # on a single dataclass per interface for unified-stats consumers.
    packet_stats_rx = PacketStatsRx()
    packet_stats_tx = PacketStatsTx()
    link_stats = LinkStatsCounters()

    tx_ring = TxRing(fd=fd, mtu=mtu, packet_stats=packet_stats_tx, link_stats=link_stats)
    rx_ring = RxRing(fd=fd, mtu=mtu, packet_stats=packet_stats_rx, link_stats=link_stats)
    nd_cache = NdCache()
    arp_cache: ArpCache | None = None

    packet_handler: PacketHandlerL2 | PacketHandlerL3
    if layer == InterfaceLayer.L2:
        assert mac_address is not None, "MAC address must be provided for Layer 2 (TAP) interface."
        arp_cache = ArpCache()
        packet_handler = PacketHandlerL2(
            mac_address=mac_address,
            interface_mtu=mtu,
            interface_name=interface_name,
            ip4_support=ip4_support,
            ip4_host=ip4_host,
            ip4_dhcp=ip4_dhcp,
            ip6_support=ip6_support,
            ip6_host=ip6_host,
            ip6_gua_autoconfig=ip6_gua_autoconfig,
            ip6_lla_autoconfig=ip6_lla_autoconfig,
            rx_ring=rx_ring,
            tx_ring=tx_ring,
            packet_stats_rx=packet_stats_rx,
            packet_stats_tx=packet_stats_tx,
            link_stats=link_stats,
        )
        # Bind the per-interface neighbor caches to this handler
        # and the reverse owner back-reference so the caches'
        # solicit / flush callbacks route through this interface.
        # ARP is L2-only; ND is used by both layers. '_iface_name'
        # plumbs the interface name into the per-iface
        # 'neighbor.<ifname>.*' sysctl resolution path.
        packet_handler._arp_cache = arp_cache
        packet_handler._nd_cache = nd_cache
        arp_cache._owner = packet_handler
        arp_cache._iface_name = interface_name
        nd_cache._owner = packet_handler
        nd_cache._iface_name = interface_name
    elif layer == InterfaceLayer.L3:
        assert mac_address is None, "MAC address must NOT be provided for Layer 3 (TUN) interface."
        packet_handler = PacketHandlerL3(
            interface_mtu=mtu,
            interface_name=interface_name,
            ip4_support=ip4_support,
            ip4_host=ip4_host,
            ip6_support=ip6_support,
            ip6_host=ip6_host,
            rx_ring=rx_ring,
            tx_ring=tx_ring,
            packet_stats_rx=packet_stats_rx,
            packet_stats_tx=packet_stats_tx,
            link_stats=link_stats,
        )
        # L3 (TUN) has no ARP; bind only the ND cache + its owner.
        packet_handler._nd_cache = nd_cache
        nd_cache._owner = packet_handler
        nd_cache._iface_name = interface_name

    # The table allocates the next ifindex (first_ifindex when empty,
    # else max+1) and stamps it onto the handler, atomically under its
    # lock so concurrent runtime adds cannot collide on an index.
    ifindex = _stack.interfaces.add(packet_handler)

    # Route state is global (shared across interfaces). Inject the
    # Route API if it already exists (a runtime add_interface call);
    # for the boot interface 'init()' builds the FIB after this
    # returns and injects the Route API itself.
    route = getattr(_stack, "route", None)
    if route is not None:
        packet_handler._route_api = route

    # Per-interface DHCPv4 / RFC 3927 link-local subsystems (L2-only;
    # both depend on Ethernet/ARP). Built HERE so the interface owns its
    # own client(s) — each binds to THIS interface via the control tools'
    # 'interface(ifindex)' view, never the bare singleton. The
    # 'stack.dhcp4_client' / 'stack.link_local' module slots are boot
    # shims (Phase 6: per-ifindex, parallel to 'stack.packet_handler').
    # The control tools ('stack.address' / 'stack.link' / 'stack.route')
    # are built by 'init()' before it delegates here, so the views
    # resolve.
    if layer is InterfaceLayer.L2 and ip4_dhcp:
        # MAC + address operations route through the public Link / Address
        # tools (bound to this interface), so DHCP construction has no
        # reach-through into packet-handler internals. The assertion
        # narrows 'MacAddress | None' → 'MacAddress' for mypy; on L2 the
        # MAC is always populated.
        address_view = _stack.address.interface(ifindex)
        dhcp_mac = _stack.link.interface(ifindex).mac_address
        assert dhcp_mac is not None, "L2 interface must expose a unicast MAC via the link tool."
        # RFC 5227 ACD runs in userspace over the AF_PACKET socket
        # (Phase 4) — the pre-lease Probe and the BOUND Announcement
        # delegate to the Ip4Acd engine, NOT the Address API. The
        # Address API stays only for the BOUND-transition address
        # install (RTM_NEWADDR).
        assert isinstance(packet_handler, PacketHandlerL2)
        packet_handler._dhcp4_client = Dhcp4Client(
            mac_address=dhcp_mac,
            acd=Ip4Acd(mac_address=dhcp_mac, ifindex=ifindex),
            address_api=address_view,
            route_api=_stack.route,
            interface_name=interface_name,
        )
        # N=1 back-compat: 'stack.dhcp4_client' aliases the FIRST (boot)
        # DHCPv4 interface's client for single-interface consumers; real
        # ownership is per-interface on the handler so a multi-homed host
        # runs one DHCP lifecycle per NIC.
        if _stack.dhcp4_client is None:
            _stack.dhcp4_client = packet_handler._dhcp4_client

    # Per-interface DHCPv6 client (RFC 8415; L2-only — needs link-scoped
    # multicast). Unlike DHCPv4 there is no opt-in flag: DHCPv6 is
    # RA-driven, so the client is installed whenever IPv6 is enabled and
    # the RA RX handler triggers it on an inbound RA's Managed /
    # Other-config flags. The leased address installs through the public
    # Address tool (bound to this interface), never a packet-handler
    # reach-through.
    #
    # The 'isinstance(_stack.address, AddressApi)' guard makes the client
    # contingent on the Address control plane being up — always the case
    # in production ('init()' builds the control tools before delegating
    # here), and the signal that a narrow unit test exercising
    # 'add_interface' in isolation has not stood the tools up (in which
    # case there is nothing to bind the client to and it is skipped).
    # 'No isinstance(packet_handler, PacketHandlerL2)' narrowing is
    # needed (unlike the DHCPv4 block): '_dhcp6_client' is declared on
    # the base 'PacketHandler', so the assignment type-checks on the
    # 'PacketHandlerL2 | PacketHandlerL3' union directly.
    if layer is InterfaceLayer.L2 and ip6_support and isinstance(_stack.address, AddressApi):
        dhcp6_address_view = _stack.address.interface(ifindex)
        dhcp6_mac = _stack.link.interface(ifindex).mac_address
        assert dhcp6_mac is not None, "L2 interface must expose a unicast MAC via the link tool."
        packet_handler._dhcp6_client = Dhcp6Client(
            mac_address=dhcp6_mac,
            interface_name=interface_name,
            address_api=dhcp6_address_view,
        )
        # N=1 back-compat alias, parallel to 'stack.dhcp4_client'.
        if _stack.dhcp6_client is None:
            _stack.dhcp6_client = packet_handler._dhcp6_client

    if layer is InterfaceLayer.L2 and ip4_link_local:
        assert isinstance(packet_handler, PacketHandlerL2)
        ll_handler = packet_handler
        ll_address_view = _stack.address.interface(ifindex)
        ll_mac = _stack.link.interface(ifindex).mac_address
        assert ll_mac is not None, "L2 interface must expose a unicast MAC via the link tool."
        from pmd_pytcp.protocols.dhcp4.dhcp4__client import Dhcp4State

        def _is_dhcp_bound() -> bool:
            client = ll_handler._dhcp4_client
            return client is not None and client.state is Dhcp4State.BOUND

        from pmd_pytcp.protocols.ip4.link_local.link_local__client import Ip4LinkLocal as _Ip4LinkLocal

        _stack.link_local = _Ip4LinkLocal(
            mac_address=ll_mac,
            address_api=ll_address_view,
            acd=Ip4Acd(mac_address=ll_mac, ifindex=ifindex),
            is_dhcp_bound=_is_dhcp_bound,
        )

    # Daemon runtime path (RTM_NEWLINK): when the stack is already
    # running, bring the new interface's subsystem threads up on the
    # spot. At boot the stack is not yet running, so the pending
    # 'stack.start()' starts every registered interface instead.
    if _stack.stack_running:
        _start_interface(packet_handler)

    return ifindex


def _purge_interface_state(iface: PacketHandlerL2 | PacketHandlerL3, /) -> None:
    """
    Run the 'RTM_DELLINK' teardown cascade for one interface's
    addresses, neighbour caches, routes and DHCP client — BEFORE it
    leaves the registry, so session-abort RSTs still egress the live
    interface and address-keyed lookups still resolve it:

      1. Remove every unicast address (one RTM_DELADDR per address) via
         the Address API. Each removal ABORTs the TCP sessions bound to
         that address (RFC 5227 §2.4) and drops it from the interface,
         so the connected routes synthesized from the address list
         vanish with the interface.
      2. Flush the interface's neighbour caches via the Neighbor API —
         ARP for an L2 interface, ND for every interface ('ip neighbor
         flush dev <ifX>').
      3. Purge explicitly-installed FIB routes that egress this
         interface ('oif' == ifindex) from both address families.
      4. Stop the per-interface DHCPv4 client — a Subsystem thread the
         per-interface thread-teardown does not own, so a leaked client
         would keep renewing a lease on a removed NIC.
    """

    import pmd_pytcp.stack as _stack

    address_api = AddressApi(packet_handler=iface)
    ifaddrs: list[Ip4IfAddr | Ip6IfAddr] = [*iface._ip4_ifaddr, *iface._ip6_ifaddr]
    for ifaddr in ifaddrs:
        address_api.remove(address=ifaddr.address)

    neighbor_api = NeighborApi(packet_handler=iface)
    if iface._arp_cache is not None:
        neighbor_api.flush(family=AddressFamily.INET4)
    neighbor_api.flush(family=AddressFamily.INET6)

    ip4_fib = getattr(_stack, "ip4_fib", None)
    if ip4_fib is not None:
        ip4_fib.remove_by_oif(oif=iface._ifindex)
    ip6_fib = getattr(_stack, "ip6_fib", None)
    if ip6_fib is not None:
        ip6_fib.remove_by_oif(oif=iface._ifindex)

    if isinstance(iface, PacketHandlerL2) and iface._dhcp4_client is not None:
        iface._dhcp4_client.stop()
    if isinstance(iface, PacketHandlerL2) and iface._dhcp6_client is not None:
        iface._dhcp6_client.stop()


def remove_interface(ifindex: int, /) -> PacketHandlerL2 | PacketHandlerL3 | None:
    """
    Remove the interface registered under 'ifindex' — the RTNETLINK
    'RTM_DELLINK' equivalent. On a running stack it first runs the
    teardown cascade ('_purge_interface_state': abort bound TCP
    sessions, drop addresses, flush neighbour caches, purge egress
    routes, stop the DHCPv4 client), then stops its subsystem threads
    (handler + rings + neighbor caches); finally it deregisters the
    interface from 'stack.interfaces'. Returns the removed handler, or
    None when no interface is registered under 'ifindex'.

    The cascade runs only on a running stack — a stopped stack has no
    live sessions or threads, and 'init()' rebuilds every interface
    from scratch, so a stopped-stack removal is a pure deregister.
    """

    import pmd_pytcp.stack as _stack

    iface = _stack.interfaces.get(ifindex)
    if iface is None:
        return None
    # Cascade + thread teardown BEFORE deregistering, so the abort RSTs
    # egress the still-registered interface and its address-derived
    # connected routes are still resolvable while sessions are torn down.
    if _stack.stack_running:
        _purge_interface_state(iface)
        _stop_interface(iface)
    _stack.interfaces.pop(ifindex)
    return iface


def init(
    *,
    fd: int | None = None,
    layer: InterfaceLayer | None = None,
    mtu: int = 1500,
    mac_address: MacAddress | None = None,
    interface_name: str | None = None,
    ip4_support: bool = True,
    ip4_host: Ip4IfAddr | None = None,
    ip4_dhcp: bool | None = None,
    ip4_link_local: bool = False,
    ip6_support: bool = True,
    ip6_host: Ip6IfAddr | None = None,
    ip6_gua_autoconfig: bool | None = None,
    ip6_lla_autoconfig: bool = True,
    sysctls: dict[str, Any] | None = None,
) -> None:
    """
    Initialize stack components.

    With no 'fd' / 'layer' the stack comes up with ZERO interfaces —
    the daemon-shaped resting state (timer, empty interface registry,
    global FIBs + Route API, and the unbound control tools). Attach a
    device afterwards with 'add_interface(...)'. With 'fd' / 'layer'
    supplied (the interim back-compat convenience) 'init()' also builds
    that one boot interface by delegating to 'add_interface', and wires
    the per-interface DHCPv4 / link-local subsystems to it.
    """

    import pmd_pytcp.stack as _stack

    # The boot interface is optional: 'init(fd=..., layer=...)' brings
    # one up; bare 'init()' leaves the registry empty for a later
    # 'add_interface'. Narrows 'fd' / 'layer' to non-None below.
    has_interface = fd is not None and layer is not None

    # Resolve None-valued kwargs against the stack-level
    # config constants. The legacy form used these constants
    # as default-expression values, which evaluated at module
    # import — meaning a test changing 'stack.IP4_ADDRESS'
    # would not affect a later 'init()' call. Move the
    # resolution into the body so each invocation sees the
    # current values.
    if ip4_host is None and _stack.IP4_ADDRESS is not None:
        ip4_host = Ip4IfAddr(_stack.IP4_ADDRESS)
    if ip4_dhcp is None:
        ip4_dhcp = _stack.IP4_ADDRESS is None
    if ip6_host is None and _stack.IP6_ADDRESS is not None:
        ip6_host = Ip6IfAddr(_stack.IP6_ADDRESS)
    if ip6_gua_autoconfig is None:
        ip6_gua_autoconfig = _stack.IP6_ADDRESS is None

    # Apply any operator overrides for the registered sysctl
    # knobs before subsystems are constructed. The bag-form
    # 'sysctls={"arp.X": ..., "neighbor.X": ...}' is keyed by
    # the dotted-name canonical key. Per-knob validators run on
    # each set(); cross-knob constraints
    # ('finalize_validators') run after the bag is fully
    # applied. Importing 'arp__constants' / 'neighbor__constants'
    # triggers their module-level 'register' calls so the
    # registry is populated before we set anything.
    from pmd_pytcp.lib import neighbor__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.arp import arp__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.icmp import icmp__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.icmp6.nd import nd__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.ip4 import ip4__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.ip4.link_local import (  # noqa: F401  pylint: disable=unused-import
        link_local__constants,
    )
    from pmd_pytcp.protocols.ip6 import ip6__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.protocols.tcp import tcp__constants  # noqa: F401  pylint: disable=unused-import
    from pmd_pytcp.stack import sysctl as sysctl_module

    if sysctls is not None:
        for key, value in sysctls.items():
            sysctl_module.set(key, value)
    sysctl_module.finalize_validators()

    # Arm the hot-path logging gate ('log.enabled') against the live
    # logging configuration. With the 'pmd_pytcp' logger below DEBUG
    # (the embedded-library default) every 'log.enabled and log(...)'
    # site now short-circuits before building its message string.
    refresh_log_enabled()

    _stack.timer = Timer()
    _stack.interfaces = InterfaceTable(first_ifindex=_stack.STACK__DEFAULT_IFINDEX)

    # IPv4 address-control API + link-control surface — built as the
    # UNBOUND, device-independent "userspace tools" (the 'ip addr' /
    # 'ip link' model), NOT pinned to a boot interface. The unbound tool
    # has no default device: every per-interface op MUST select one via
    # '.interface(ifindex)' (Linux 'ip ... dev <ifX>'); a bare per-device
    # op raises. Built BEFORE 'add_interface' so the per-interface DHCP /
    # link-local subsystems it constructs can bind to their own
    # 'interface(ifindex)' view. See 'docs/refactor/link_api.md'.
    _stack.address = AddressApi()
    _stack.link = LinkApi()
    _stack.neighbor = NeighborApi()
    _stack.membership = MembershipApi()

    # Host-mode routing table — Phase 3 of
    # 'docs/refactor/routing_table_host_mode.md'. Build the two FIBs and
    # the Route API BEFORE 'add_interface' so the latter injects
    # '_route_api' into the new handler itself (no separate post-injection
    # needed). The static boot-config gateway is a boot-interface
    # convenience installed only when an interface is built; with zero
    # interfaces the FIBs come up empty (a daemon adds routes as
    # interfaces + addresses attach). The next hop is FIB state — DHCP /
    # RA / autoconfig install their learned gateway at runtime via
    # 'RouteApi.replace_default_ip{4,6}'.
    ip4_fib: RouteTable[Ip4Address, Ip4Network] = RouteTable()
    ip6_fib: RouteTable[Ip6Address, Ip6Network] = RouteTable()
    if has_interface:
        install_boot_default_routes(
            ip4_fib=ip4_fib,
            ip6_fib=ip6_fib,
            ip4_gateway=_stack.IP4_GATEWAY,
            ip6_gateway=_stack.IP6_GATEWAY,
        )
    _stack.ip4_fib = ip4_fib
    _stack.ip6_fib = ip6_fib
    _stack.route = RouteApi(ip4_fib=ip4_fib, ip6_fib=ip6_fib)

    # Per-interface subsystem slots default to None; 'add_interface'
    # populates them (boot shims) when it builds a DHCP / link-local
    # client for an L2 interface. With zero interfaces they stay None.
    _stack.dhcp4_client = None
    _stack.dhcp6_client = None
    _stack.link_local = None

    # Boot interface (interim back-compat convenience): when 'fd' /
    # 'layer' are supplied, delegate to 'add_interface', which builds the
    # rings + neighbor caches + handler, populates the N=1 back-compat
    # singletons, injects the Route API, and constructs this interface's
    # own DHCPv4 / link-local subsystems. With no 'fd' / 'layer' the
    # stack stays at zero interfaces (the daemon resting state).
    if has_interface:
        assert fd is not None and layer is not None  # narrowed by 'has_interface'
        add_interface(
            fd=fd,
            layer=layer,
            mtu=mtu,
            mac_address=mac_address,
            interface_name=interface_name,
            ip4_support=ip4_support,
            ip4_host=ip4_host,
            ip4_dhcp=bool(ip4_dhcp),
            ip4_link_local=ip4_link_local,
            ip6_support=ip6_support,
            ip6_host=ip6_host,
            ip6_gua_autoconfig=bool(ip6_gua_autoconfig),
            ip6_lla_autoconfig=ip6_lla_autoconfig,
        )

    _stack.stack_initialized = True


def _start_interface(iface: PacketHandlerL2 | PacketHandlerL3, /) -> None:
    """
    Start one interface's own subsystem threads — its neighbor
    cache(s), TX / RX rings and packet handler (the handler owns its
    injected '_rx_ring' / '_tx_ring' / '_arp_cache' / '_nd_cache').
    Shared by 'stack.start()' (boot, every registered interface) and
    'add_interface' (runtime add to an already-running stack).
    """

    if iface._arp_cache is not None:
        iface._arp_cache.start()
    assert iface._nd_cache is not None
    iface._nd_cache.start()
    assert iface._tx_ring is not None and iface._rx_ring is not None
    iface._tx_ring.start()
    iface._rx_ring.start()
    iface.start()


def _stop_interface(iface: PacketHandlerL2 | PacketHandlerL3, /) -> None:
    """
    Stop one interface's own subsystem threads — handler first (stop
    TX producers), then its rings, then its neighbor cache(s); the
    reverse of '_start_interface'. Used by 'remove_interface' to tear
    down a single interface on a running stack. ('stack.stop()' keeps
    its own global ordering — all handlers, then the shared timer, then
    all rings/caches — so it does not call this per-interface helper.)
    """

    iface.stop()
    assert iface._rx_ring is not None and iface._tx_ring is not None
    iface._rx_ring.stop()
    iface._tx_ring.stop()
    if iface._arp_cache is not None:
        iface._arp_cache.stop()
    assert iface._nd_cache is not None
    iface._nd_cache.stop()


async def start() -> None:
    """
    Start stack components. A coroutine — the stack runs entirely
    on the caller's event loop ('docs/refactor/pure_asyncio.md');
    every subsystem below is armed as loop callbacks / tasks.
    """

    import pmd_pytcp.stack as _stack

    assert _stack.stack_initialized, "Stack not initialized. Call 'stack.init()' first."

    _stack.stack_running = True

    _stack.timer.start()
    # Per-interface subsystems: start each registered interface's own
    # caches, rings and handler. At N=1 this is the single boot
    # interface; the loop is the N>1 path.
    for iface in _stack.interfaces.values():
        _start_interface(iface)

    # RFC 3927 link-local autoconfig subsystem. Start BEFORE the
    # DHCP wait so the two FSMs run in parallel — the link-local
    # subsystem's '_reconcile_with_dhcp' polls DHCP state and
    # naturally waits until 'dhcp_fallback_timeout_ms' has elapsed
    # of continuous DHCP-unbound time before claiming.
    if _stack.link_local is not None:
        _stack.link_local.start()

    # Phase 4 commit B — DHCPv4 lifecycle. Start AFTER the packet
    # handler so the TX/RX/socket plumbing is live; block up to
    # 'dhcp.boot_wait_ms' for the FSM to reach BOUND. On timeout
    # the lifecycle keeps trying in the background; boot proceeds
    # without IPv4 for now.
    dhcp4_clients = [
        handler._dhcp4_client
        for handler in _stack.interfaces.values()
        if isinstance(handler, PacketHandlerL2) and handler._dhcp4_client is not None
    ]
    if dhcp4_clients:
        from pmd_pytcp.protocols.dhcp4 import dhcp4__constants

        boot_wait_s = dhcp4__constants.DHCP4__BOOT_WAIT_MS / 1000.0
        for dhcp4_client in dhcp4_clients:
            bound = await dhcp4_client.start_and_wait_for_bind(timeout_s=boot_wait_s)
            if bound:
                log.enabled and log("stack", "DHCPv4 lifecycle reached BOUND during boot")
            else:
                log.enabled and log(
                    "stack",
                    f"<WARN>DHCPv4 lifecycle did not reach BOUND within "
                    f"{boot_wait_s:.1f}s; proceeding without IPv4 (lifecycle "
                    f"continues in background)</>",
                )

    # DHCPv6 lifecycle (RFC 8415). Start the worker threads AFTER the
    # packet handler so the TX/RX/socket plumbing is live. No boot wait —
    # DHCPv6 is RA-triggered (not boot-blocking); each worker idles until
    # the RA RX handler triggers it on an inbound RA's Managed /
    # Other-config flags.
    for handler in _stack.interfaces.values():
        if isinstance(handler, PacketHandlerL2) and handler._dhcp6_client is not None:
            handler._dhcp6_client.start()


def _abort_open_sockets() -> None:
    """
    Abort every registered connection-oriented socket (TCP) so any
    task awaiting the socket's 'recv()' / 'connect()' coroutine
    unblocks with a connection error instead of staying parked
    forever — after teardown nothing ever sets those sessions'
    events again, so a coroutine still awaiting one would hang for
    the loop's lifetime. Called from 'stop()' while the TX path is
    still live so the RFC 9293 §3.9.1 RSTs emitted for synchronized
    states actually reach the peers. Datagram / raw sockets have no
    'abort' (nothing blocks beyond per-call timeouts the caller
    opted into) and are skipped; a raising 'abort' is logged and
    skipped so one bad session cannot stall stack teardown.
    """

    import pmd_pytcp.stack as _stack

    for sock in _stack.sockets.values():
        abort = getattr(sock, "abort", None)
        if abort is None:
            continue
        try:
            abort()
        except Exception as error:  # pylint: disable=broad-exception-caught
            log.enabled and log(
                "stack",
                f"<WARN>Aborting {sock} during stop() raised {type(error).__name__}: {error}</>",
            )


async def stop() -> None:
    """
    Stop stack components. A coroutine — after signalling every
    subsystem it awaits the worker tasks' actual exit so a caller
    returning from 'stop()' observes a fully quiesced stack.
    """

    import pmd_pytcp.stack as _stack

    assert _stack.stack_initialized, "Stack not initialized. Call 'stack.init()' first."

    # Graceful multicast Leave: while the TX path is still fully live
    # (before any subsystem teardown below), announce departure from
    # every joined IPv4 multicast group so routers prune the host's
    # memberships immediately instead of waiting for a query timeout
    # (RFC 3376 §5.1; Linux 'ip_mc_down').
    for iface in _stack.interfaces.values():
        iface._send_igmp_leave_all()

    # Abort open TCP sessions while TX is still live: peers get their
    # RSTs, and tasks awaiting a socket's recv()/connect() coroutine
    # unblock with a connection error instead of hanging past teardown.
    _abort_open_sockets()

    _stack.stack_running = False

    # Teardown order:
    #   0. dhcp4_client    — stop the DHCPv4 lifecycle FIRST so any
    #                        in-flight RENEW/REBIND/RELEASE work
    #                        completes against still-live sockets.
    #   1. packet_handler  — stop application-side TX producers.
    #   2. timer           — stop periodic callbacks (TCP RTO,
    #                        persist, keep-alive, delayed-ACK) so
    #                        they cannot enqueue to a stopped tx_ring.
    #   3. rx_ring         — stop kernel reads.
    #   4. tx_ring         — drain anything still queued + stop.
    #   5. arp_cache / nd_cache — stop cache-refresh threads.
    stopped_subsystems = []
    for handler in _stack.interfaces.values():
        if isinstance(handler, PacketHandlerL2) and handler._dhcp4_client is not None:
            handler._dhcp4_client.stop()
            stopped_subsystems.append(handler._dhcp4_client)
        if isinstance(handler, PacketHandlerL2) and handler._dhcp6_client is not None:
            handler._dhcp6_client.stop()
            stopped_subsystems.append(handler._dhcp6_client)
    if _stack.link_local is not None:
        _stack.link_local.stop()
        stopped_subsystems.append(_stack.link_local)
    # Per-interface handlers first (stop application-side TX
    # producers), then the shared timer (so periodic callbacks cannot
    # enqueue onto a stopped ring), then each interface's rings +
    # caches. At N=1 this is the single boot interface.
    for iface in _stack.interfaces.values():
        iface.stop()
        stopped_subsystems.append(iface)
    _stack.timer.stop()
    for iface in _stack.interfaces.values():
        assert iface._rx_ring is not None and iface._tx_ring is not None
        iface._rx_ring.stop()
        iface._tx_ring.stop()
        if iface._arp_cache is not None:
            iface._arp_cache.stop()
            stopped_subsystems.append(iface._arp_cache)
        assert iface._nd_cache is not None
        iface._nd_cache.stop()
        stopped_subsystems.append(iface._nd_cache)

    # Await every cancelled worker's actual exit so teardown is
    # complete (not merely signalled) when 'stop()' returns.
    for subsystem in stopped_subsystems:
        wait_stopped = getattr(subsystem, "wait_stopped", None)
        if wait_stopped is not None:
            await wait_stopped()

    # Restore every registered sysctl to its compile-time default
    # so a follow-up 'stack.init()' (typical in long-running test
    # harnesses) starts from a clean baseline rather than
    # inheriting overrides from the prior run.
    from pmd_pytcp.stack import sysctl as sysctl_module

    sysctl_module.reset_to_defaults()
